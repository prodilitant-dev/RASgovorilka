// src/modes/learning/sorting/Sorting.view.js
import { createElement, clear } from '@utils/dom';
import { getImageUrl } from '@services/imageService';
import { logger } from '@utils/logger';

export function renderSortingGame(container, state, onDrop) {
  logger.debug(`🔄 Rendering Sorting Game, ${state.remainingCards.length} cards left`);
  clear(container);

  const wrap = createElement('div', { className: 'grid-container flex-mode' });
  const area = createElement('div', { className: 'sorting-area' });

  // Контейнер для карточек (горизонтальный ряд, перенос)
  const cardsWrap = createElement('div', { className: 'sorting-cards' });
  cardsWrap.style.display = 'flex';
  cardsWrap.style.flexWrap = 'wrap';
  cardsWrap.style.gap = 'var(--spacing-sm)';
  cardsWrap.style.justifyContent = 'center';
  cardsWrap.style.padding = 'var(--spacing-sm)';
  cardsWrap.style.minHeight = '100px';

  state.remainingCards.forEach(card => {
    // ✅ Используем класс card (как в остальных режимах)
    const cardEl = createElement('div', {
      className: 'card card--sort',
      draggable: true,
      'data-id': card.id,
    });

    // Фон (изображение или эмодзи)
    const bg = createElement('div', { className: 'card__bg' });
    if (card.imageId) {
      bg.textContent = '🔄';
      getImageUrl(card.imageId).then(url => {
        if (url) {
          bg.style.backgroundImage = `url(${url})`;
          bg.textContent = '';
        } else {
          bg.textContent = card.emoji || '📄';
        }
      });
    } else {
      bg.textContent = card.emoji || '📄';
    }
    cardEl.appendChild(bg);

    // Подпись
    const label = createElement('div', { className: 'card__label' }, card.text);
    cardEl.appendChild(label);

    // Drag-обработчик
    cardEl.addEventListener('dragstart', (e) => {
      e.dataTransfer.setData('text/plain', JSON.stringify({
        type: 'sorting-card',
        id: card.id,
      }));
      e.dataTransfer.effectAllowed = 'move';
    });

    cardsWrap.appendChild(cardEl);
  });

  area.appendChild(cardsWrap);

  // Зоны сортировки (без изменений)
  const zonesWrap = createElement('div', { className: 'sorting-zones' });
  state.zones.forEach(zone => {
    const zoneEl = createElement('div', {
      className: 'sorting-zone',
      'data-category-id': zone.categoryId,
    });

    const title = createElement('div', { className: 'zone-title' }, zone.name);
    zoneEl.appendChild(title);

    const itemsWrap = createElement('div', { className: 'zone-items' });
    zone.items.forEach(item => {
      const itemEl = createElement('span', {
        className: `placed-item ${item.isCorrect ? 'correct' : 'wrong'}`,
      }, `${item.emoji || ''} ${item.text}`);
      itemsWrap.appendChild(itemEl);
    });
    zoneEl.appendChild(itemsWrap);

    zoneEl.addEventListener('dragover', (e) => {
      e.preventDefault();
      e.dataTransfer.dropEffect = 'move';
    });
    zoneEl.addEventListener('drop', (e) => {
      e.preventDefault();
      const rawData = e.dataTransfer.getData('text/plain');
      if (!rawData) return;
      try {
        const data = JSON.parse(rawData);
        if (data.type === 'sorting-card') {
          onDrop(data.id, zone.categoryId);
        }
      } catch {
        onDrop(rawData, zone.categoryId);
      }
    });

    zonesWrap.appendChild(zoneEl);
  });
  area.appendChild(zonesWrap);

  wrap.appendChild(area);
  container.appendChild(wrap);

  if (state.remainingCards.length === 0) {
    const doneMsg = createElement('div', {
      style: 'text-align:center; padding:20px; font-size:18px; color: var(--primary);',
    }, 'Все карточки отсортированы! ✅');
    wrap.appendChild(doneMsg);
  }
}