// src/modes/learning/quiz/Quiz.view.js
import { createElement, clear } from '@utils/dom';
import { renderProgressBar } from '@components/common/ProgressBar';
import { getImageUrl } from '@services/imageService';
import { logger } from '@utils/logger';

export function renderQuizQuestion(container, {
  question,
  options = [], // ✅ Добавляем значение по умолчанию
  current,
  total,
  onAnswer,
  feedback = null,
  isCorrect = false,
  userAnswer = null,
}) {
  logger.debug(`🔄 Rendering Quiz Question ${current}/${total}`);
  clear(container);

  const wrap = createElement('div', { className: 'grid-container flex-mode' });
  const card = createElement('div', { className: 'learning-card' });

  // Прогресс
  const progressWrap = createElement('div', { className: 'w-full' });
  renderProgressBar(progressWrap, current, total);
  card.appendChild(progressWrap);

  // Изображение
  const image = createElement('div', { className: 'card-image' });
  if (question.imageId) {
    image.textContent = '🖼️';
    getImageUrl(question.imageId).then(url => {
      if (url) {
        image.style.backgroundImage = `url(${url})`;
        image.textContent = '';
      } else {
        image.textContent = '❓';
      }
    });
  } else {
    image.textContent = question.emoji || '❓';
  }
  card.appendChild(image);

  // Текст вопроса
  const text = createElement('div', { className: 'card-text' }, question.text || 'Что на картинке?');
  card.appendChild(text);

  // Варианты ответов
  const optionsGrid = createElement('div', { className: 'options-grid' });
  if (options && options.length > 0) {
    options.forEach(opt => {
      const btn = createElement('button', {
        className: `btn ${feedback && opt.id === userAnswer ? (isCorrect ? 'btn-primary' : 'btn-danger') : ''}`,
      }, opt.emoji ? `${opt.emoji} ${opt.text}` : opt.text);

      if (onAnswer) {
        btn.addEventListener('click', () => onAnswer(opt.id));
      } else {
        btn.disabled = true;
        btn.style.opacity = '0.6';
      }
      optionsGrid.appendChild(btn);
    });
  } else {
    // Если нет вариантов – показываем сообщение
    const emptyMsg = createElement('div', { className: 'text-muted' }, 'Нет вариантов ответа');
    optionsGrid.appendChild(emptyMsg);
  }
  card.appendChild(optionsGrid);

  // Обратная связь (если есть)
  if (feedback) {
    const fb = createElement('div', {
      className: `feedback ${isCorrect ? 'correct' : 'wrong'}`,
    }, feedback);
    card.appendChild(fb);
  }

  wrap.appendChild(card);
  container.appendChild(wrap);
}