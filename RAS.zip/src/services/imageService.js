// src/services/imageService.js
import { loadImage } from '@storage/imageStorage';

const cache = new Map();

export async function getImageUrl(imageId) {
  if (!imageId) return null;
  if (cache.has(imageId)) return cache.get(imageId);
  const blob = await loadImage(imageId);
  if (!blob) return null;
  const url = URL.createObjectURL(blob);
  cache.set(imageId, url);
  return url;
}

export function revokeImageUrl(imageId) {
  if (cache.has(imageId)) {
    URL.revokeObjectURL(cache.get(imageId));
    cache.delete(imageId);
  }
}

export function clearCache() {
  for (const [id, url] of cache) {
    URL.revokeObjectURL(url);
  }
  cache.clear();
}